var config = {
    basePort: 8000
};

module.exports = config;